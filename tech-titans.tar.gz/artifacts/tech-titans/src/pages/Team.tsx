import React from "react";
import { motion } from "framer-motion";
import { Link } from "wouter";
import { members } from "@/data/members";
import { ArrowUpRight } from "lucide-react";

export function Team() {
  return (
    <div className="max-w-7xl mx-auto px-6 py-24 w-full">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="mb-16"
      >
        <h1 className="text-4xl md:text-6xl font-display font-bold text-white mb-6">
          The Squad
        </h1>
        <p className="text-xl text-muted-foreground max-w-2xl">
          Four distinct perspectives. One unified vision. Get to know the minds behind the pixels and code.
        </p>
      </motion.div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {members.map((member, idx) => (
          <motion.div
            key={member.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: idx * 0.1 }}
          >
            <Link href={`/team/${member.id}`}>
              <div className="group block h-full bg-card border border-border hover:border-primary/50 rounded-2xl p-8 transition-all duration-300 relative overflow-hidden">
                <div className="absolute inset-0 bg-gradient-to-br from-primary/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
                
                <div className="relative z-10 flex justify-between items-start">
                  <div>
                    <h2 className="text-2xl font-display font-bold text-white mb-2 group-hover:text-primary transition-colors">
                      {member.name}
                    </h2>
                    <p className="text-primary/80 font-medium text-sm tracking-wide mb-6">
                      {member.role.toUpperCase()}
                    </p>
                    <p className="text-muted-foreground line-clamp-2">
                      {member.bio}
                    </p>
                  </div>
                  <div className="w-10 h-10 rounded-full bg-background border border-border flex items-center justify-center group-hover:bg-primary group-hover:border-primary transition-colors shrink-0">
                    <ArrowUpRight className="w-5 h-5 text-muted-foreground group-hover:text-background transition-colors" />
                  </div>
                </div>
              </div>
            </Link>
          </motion.div>
        ))}
      </div>
    </div>
  );
}

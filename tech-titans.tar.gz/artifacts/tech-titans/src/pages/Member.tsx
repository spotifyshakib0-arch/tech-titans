import React from "react";
import { useRoute, Link } from "wouter";
import { motion } from "framer-motion";
import { members } from "@/data/members";
import { ArrowLeft, Github, Twitter, Mail } from "lucide-react";
import NotFound from "./not-found";

export function Member() {
  const [match, params] = useRoute("/team/:id");
  const id = params?.id;
  
  const member = members.find(m => m.id === id);

  if (!member) {
    return <NotFound />;
  }

  return (
    <div className="max-w-4xl mx-auto px-6 py-24 w-full">
      <motion.div
        initial={{ opacity: 0, x: -20 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ duration: 0.3 }}
        className="mb-12"
      >
        <Link 
          href="/team" 
          className="inline-flex items-center gap-2 text-muted-foreground hover:text-primary transition-colors font-medium text-sm"
        >
          <ArrowLeft className="w-4 h-4" /> Back to Team
        </Link>
      </motion.div>

      <div className="bg-card border border-border rounded-3xl p-8 md:p-12 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-primary/10 blur-[100px] rounded-full pointer-events-none translate-x-1/2 -translate-y-1/2" />
        
        <div className="relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.1 }}
          >
            <h1 className="text-5xl md:text-7xl font-display font-bold text-white mb-4">
              {member.name}
            </h1>
            <p className="text-xl md:text-2xl text-primary font-medium tracking-wide mb-10">
              {member.role}
            </p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
            className="prose prose-invert prose-lg max-w-none mb-16 text-muted-foreground"
          >
            <p>{member.bio}</p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.3 }}
            className="mb-16"
          >
            <h3 className="text-lg font-display font-semibold text-white mb-6 uppercase tracking-wider">Tech Arsenal</h3>
            <div className="flex flex-wrap gap-3">
              {member.skills.map((skill, idx) => (
                <span 
                  key={idx}
                  className="px-4 py-2 rounded-full bg-background border border-border text-sm font-medium text-muted-foreground hover:border-primary/50 hover:text-white transition-colors"
                >
                  {skill}
                </span>
              ))}
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.4 }}
            className="flex flex-wrap items-center gap-6 pt-8 border-t border-border/50"
          >
            <a 
              href={`mailto:${member.contactEmail}`}
              className="inline-flex items-center gap-2 bg-white text-background px-6 py-3 rounded-full font-bold hover:bg-primary hover:text-white transition-all duration-300 shadow-[0_0_15px_hsl(var(--primary)/0.2)] hover:shadow-[0_0_25px_hsl(var(--primary)/0.5)]"
            >
              <Mail className="w-5 h-5" /> Get in touch
            </a>
            
            <div className="flex items-center gap-4">
              {member.github && (
                <a href={`https://${member.github}`} target="_blank" rel="noopener noreferrer" className="w-12 h-12 rounded-full bg-background border border-border flex items-center justify-center text-muted-foreground hover:text-white hover:border-primary transition-colors">
                  <Github className="w-5 h-5" />
                </a>
              )}
              {member.twitter && (
                <a href={`https://${member.twitter}`} target="_blank" rel="noopener noreferrer" className="w-12 h-12 rounded-full bg-background border border-border flex items-center justify-center text-muted-foreground hover:text-white hover:border-primary transition-colors">
                  <Twitter className="w-5 h-5" />
                </a>
              )}
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
}

export interface TeamMember {
  id: string;
  name: string;
  role: string;
  bio: string;
  skills: string[];
  contactEmail: string;
  github?: string;
  twitter?: string;
}

export const members: TeamMember[] = [
  {
    id: "aqshif",
    name: "Aqshif Ahamed",
    role: "Web Developer & Graphic Designer",
    bio: "Aqshif bridges the gap between striking visual communication and robust technical execution. With an eye for typography and a deep understanding of modern CSS frameworks, he crafts interfaces that don't just work—they make an impact. When he isn't fine-tuning animations, he's exploring new brand identities.",
    skills: ["React", "TypeScript", "Tailwind CSS", "Figma", "Framer Motion", "Adobe Illustrator"],
    contactEmail: "aqshif@techtitans.dev",
    github: "github.com/aqshif",
    twitter: "twitter.com/aqshif"
  },
  {
    id: "skakib",
    name: "Skakib Ahamed",
    role: "Web Developer & Graphic Designer",
    bio: "Skakib is a meticulous creator who obsesses over the details. He specializes in building accessible, high-performance web applications with a focus on polished UI components. His background in graphic design gives him a unique perspective on layout composition and user flow.",
    skills: ["Next.js", "Vue", "CSS Architecture", "UI/UX Design", "Three.js", "Photoshop"],
    contactEmail: "skakib@techtitans.dev",
    github: "github.com/skakib"
  },
  {
    id: "yoosuf",
    name: "Yoosuf Al Asjath",
    role: "Web Developer & Graphic Designer",
    bio: "Yoosuf engineers digital experiences with a creative flair. He thrives on complex state management and interactive visualizations. His passion lies in transforming static designs into living, breathing applications that respond fluidly to user interactions.",
    skills: ["React", "Node.js", "WebGL", "Figma", "Animation", "Branding"],
    contactEmail: "yoosuf@techtitans.dev",
    twitter: "twitter.com/yoosuf"
  },
  {
    id: "abdullah",
    name: "Abdullah",
    role: "Web Developer & Graphic Designer",
    bio: "Abdullah builds the connective tissue of the web. As a full-stack thinker with strong design sensibilities, he ensures that the underlying architecture of an app is as elegant as its surface. He loves experimenting with bleeding-edge web APIs to create immersive experiences.",
    skills: ["TypeScript", "Svelte", "Tailwind CSS", "Motion Design", "Vector Graphics", "REST APIs"],
    contactEmail: "abdullah@techtitans.dev",
    github: "github.com/abdullah"
  }
];

import React from "react";
import { Link, useLocation } from "wouter";
import { motion } from "framer-motion";
import { Zap } from "lucide-react";

export function Navbar() {
  const [location] = useLocation();

  const links = [
    { href: "/", label: "Home" },
    { href: "/team", label: "Team" },
    { href: "/team/aqshif", label: "Aqshif" },
    { href: "/team/skakib", label: "Skakib" },
    { href: "/team/yoosuf", label: "Yoosuf" },
    { href: "/team/abdullah", label: "Abdullah" },
  ];

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-background/80 backdrop-blur-md border-b border-border/50">
      <div className="max-w-7xl mx-auto px-6 h-20 flex items-center justify-between">
        <Link href="/" className="flex items-center gap-2 group">
          <Zap className="w-6 h-6 text-primary group-hover:text-white transition-colors duration-300" />
          <span className="font-display font-bold text-xl tracking-tight text-white">
            Tech Titans
          </span>
        </Link>
        
        <div className="hidden md:flex items-center gap-6">
          {links.map((link) => {
            const isActive = location === link.href;
            return (
              <Link 
                key={link.href} 
                href={link.href}
                className={`text-sm font-medium transition-colors hover:text-primary relative py-2 ${
                  isActive ? "text-primary" : "text-muted-foreground"
                }`}
              >
                {link.label}
                {isActive && (
                  <motion.div
                    layoutId="navbar-indicator"
                    className="absolute bottom-0 left-0 right-0 h-[2px] bg-primary shadow-[0_0_8px_hsl(var(--primary))]"
                    initial={false}
                    transition={{ type: "spring", stiffness: 500, damping: 30 }}
                  />
                )}
              </Link>
            );
          })}
        </div>
      </div>
    </nav>
  );
}

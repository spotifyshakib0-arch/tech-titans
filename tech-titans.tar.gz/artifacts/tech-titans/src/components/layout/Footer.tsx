import React from "react";
import { Link } from "wouter";
import { Zap } from "lucide-react";

export function Footer() {
  return (
    <footer className="bg-background border-t border-border/50 py-12 mt-24">
      <div className="max-w-7xl mx-auto px-6 flex flex-col md:flex-row justify-between items-center gap-6">
        <div className="flex items-center gap-2">
          <Zap className="w-5 h-5 text-primary" />
          <span className="font-display font-semibold text-white">Tech Titans</span>
        </div>
        <p className="text-muted-foreground text-sm text-center md:text-left">
          &copy; {new Date().getFullYear()} Tech Titans Studio. Crafted with precision.
        </p>
        <div className="flex items-center gap-4 text-sm font-medium">
          <Link href="/team" className="text-muted-foreground hover:text-primary transition-colors">Meet the Team</Link>
          <a href="mailto:hello@techtitans.dev" className="text-muted-foreground hover:text-primary transition-colors">Contact</a>
        </div>
      </div>
    </footer>
  );
}
